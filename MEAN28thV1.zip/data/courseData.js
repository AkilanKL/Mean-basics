var courseData = [
    {
        "moduleIndex" : 1,
        "module" : [
            {
                "topic" : {
                    "index": 1,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 2,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 3,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 4,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 5,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 6,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 7,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            }
        ]
    },
    {
        "moduleIndex" : 2,
        "module" : [
            {
                "topic" : {
                    "index": 1,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 2,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 3,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 4,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 5,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 6,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            }
        ]
    },
    {
        "moduleIndex" : 3,
        "module" : [
            {
                "topic" : {
                    "index": 1,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 2,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 3,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 4,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 5,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 6,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 7,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 8,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            }
        ]
    },
    {
        "moduleIndex" : 4,
        "module" : [
            {
                "topic" : {
                    "index": 1,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 2,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 3,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 4,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 5,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 6,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            }
        ]
    },
    {
        "moduleIndex" : 5,
        "module" : [
            {
                "topic" : {
                    "index": 1,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 2,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 3,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 4,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 5,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 6,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 7,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 8,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            }
        ]
    },
    {
        "moduleIndex" : 6,
        "module" : [
            {
                "topic" : {
                    "index": 1,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 2,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 3,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 4,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            }

        ]
    },
    {
        "moduleIndex" : 7,
        "module" : [
            {
                "topic" : {
                    "index": 1,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 2,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 3,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 4,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 5,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 6,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            }

        ]
    },
    {
        "moduleIndex" : 8,
        "module" : [
            {
                "topic" : {
                    "index": 1,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 2,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 3,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 4,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 5,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 6,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 7,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 8,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 9,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 10,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            }

        ]
    },
    {
        "moduleIndex" : 9,
        "module" : [
            {
                "topic" : {
                    "index": 1,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 2,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 3,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 4,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 5,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 6,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 7,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            }
        ]
    },
    {
        "moduleIndex" : 10,
        "module" : [
            {
                "topic" : {
                    "index": 1,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 2,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 3,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 4,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 5,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 6,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 7,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 8,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 9,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 10,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 11,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 12,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 13,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            }

        ]
    },
    {
        "moduleIndex" : 11,
        "module" : [
            {
                "topic" : {
                    "index": 1,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 2,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 3,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 4,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 5,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 6,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 7,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 8,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            }
        ]
    },
    {
        "moduleIndex" : 12,
        "module" : [
            {
                "topic" : {
                    "index": 1,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 2,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 3,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            },
            {
                "topic" : {
                    "index": 4,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            }
        ]
    },
    {
        "moduleIndex" : 13,
        "module" : [
            {
                "topic" : {
                    "index": 1,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            }
        ]
    },
    {
        "moduleIndex" : 14,
        "module" : [
            {
                "topic" : {
                    "index": 1,
                    "completionStatus": "notCompleted",
                    "progress": ""

                }
            }
        ]
    }

]