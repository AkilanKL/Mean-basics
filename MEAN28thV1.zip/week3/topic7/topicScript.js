var module = 3;
var topic = 7;

var isVideoCompleted = false;
var videoReport = "";
var scrollReport = "";
var markCompleteReport = "";
var isPageScrollCompleted = false;
var isMarkCompleted = false;

var isParentCompleted =
  _this.trackingDataObj[module - 1].module[topic - 1].topic.completionStatus;
var iframe = document.getElementById("i_frame");
iframe.onload = function () {
  this.contentWindow.postMessage(isParentCompleted, "*");
};

window.addEventListener(
  "message",
  (event) => {
    if (event.data == "pageScrollCompleted") {
      updatePageScroll(event.data);
    }
    if (event.data == "videoCompleted" || event.data == "videoNone") {
      updateVideoCompleted(event.data);
    }
    if (event.data == "markComplete") {
      updateMarkCompleted(event.data);
    }
  },
  false
);

function updatePageScroll(event) {
  isPageScrollCompleted = true;
  storeReportLMS(event);
}
function updateVideoCompleted(event) {
  isVideoCompleted = true;
  storeReportLMS(event);
}
function updateMarkCompleted(event) {
  isMarkCompleted = true;
  storeReportLMS(event);
}

function storeReportLMS(status) {
  if (status == "videoCompleted" || status == "videoNone") {
    videoReport = "videoCompleted";
  }
  if (status == "pageScrollCompleted") {
    scrollReport = "pageScrollCompleted";
  }
  if (status == "markComplete") {
    markCompleteReport = "markComplete";
  }
  if (
    videoReport == "videoCompleted" &&
    scrollReport == "pageScrollCompleted" &&
    markCompleteReport == "markComplete"
  ) {
    storeAllDatasOnLms();
  }
}
function storeAllDatasOnLms() {
  if (_this.scormReference.isScormInitiated() == true) {
    _this.trackingDataObj[module - 1].module[topic - 1].topic.completionStatus =
      "completed";
    _this.trackingDataObj[module - 1].module[topic - 1].topic.progress = "100%";
    var trackingData = JSON.stringify(_this.trackingDataObj);
    _this.scormReference.storeTrackingData(trackingData);
    _this.storeLessonCompletionStatus("completed");
    _this.storeCourseCompletionStatus();
    _this.storeProgess();
    _this.setSessionTime();
  } else {
    _this.trackingDataObj[module - 1].module[topic - 1].topic.completionStatus =
      "completed";
    _this.trackingDataObj[module - 1].module[topic - 1].topic.progress = "100%";
    var trackingData = JSON.stringify(_this.trackingDataObj);
    localStorage.setItem("sampleScormPackage", trackingData);
    _this.storeLessonCompletionStatus("completed");
    _this.setSessionTime();
    _this.storeProgess();
  }
}


