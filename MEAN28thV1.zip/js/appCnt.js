var _this = this;

_this.trackingDataObj;
_this.courseDataReceived = false;
_this.courseData
_this.scormReference = new scormAPI();

var courseTrackingData;

var ServiceLocator = function () {
    this.loadExternalData = function(urlToLoad, isSync, errorHandler, successHandler){
        $.ajax({
            url:urlToLoad,
            async:isSync,
            error:errorHandler,
            success:successHandler
        });
    }
}

var APIService = function () {
    this.loadFromExternalSource = function(urlToLoad, isSync, errorHandler, successHandler) {

        var serviceObj = new ServiceLocator();
        serviceObj.loadExternalData(urlToLoad, isSync, errorHandler, successHandler);

    }
}

var courseDataErrorHandler = function (data) {

   
}

var courseDataSuccessHandler = function (data) {
    var trackingData;
    _this.courseDataReceived = true;
    if (_this.scormReference.isScormInitiated() == true) {
        trackingData = _this.scormReference.retrieveTrackingData();
        if(trackingData == undefined || trackingData == "" ||  trackingData == null) {
            trackingData = JSON.stringify(data)

            _this.scormReference.storeTrackingData(trackingData);
            _this.trackingDataObj = JSON.parse(trackingData);
        }else{
            _this.trackingDataObj = JSON.parse(trackingData);
        }
    }else{
        var storedData = localStorage.getItem("sampleScormPackage");
        if(storedData != null) {      
            _this.trackingDataObj = JSON.parse(storedData);
        }else{
            trackingData = JSON.stringify(data);
            localStorage.setItem("sampleScormPackage", trackingData);
            _this.trackingDataObj = JSON.parse(trackingData);

        }
    }
}
courseDataSuccessHandler(courseData)
// if(courseTrackingData != "" && courseTrackingData != undefined){

// }else{
//     var jsonService = new APIService();
//     jsonService.loadFromExternalSource("../../data/courseData.json", true, courseDataErrorHandler, courseDataSuccessHandler);
// }

_this.storeLessonCompletionStatus = function (status) {
    _this.scormReference.storeLessonStatus(status);
}

_this.storeCourseCompletionStatus = function () {
    var totalTopics = 0;
    var visitedTopics = 0;

    for(var i = 0; i < _this.trackingDataObj.length; i++) {
        for(var j = 0; j < _this.trackingDataObj[i].module.length; j++){
            totalTopics++;
            if(_this.trackingDataObj[i].module[j].topic.completionStatus == "completed"){
                visitedTopics++;
            }
        }
    }

    var retreiveCompletionStatus = _this.scormReference.retrieveCompletionStatusTracking();

    if(retreiveCompletionStatus != "completed"){
        if(visitedTopics == totalTopics) {
            _this.scormReference.storeCompletionStatusTracking("completed");
        }else{
            _this.scormReference.storeCompletionStatusTracking("incomplete");
        }
    }
}

_this.storeProgess = function () {

    var totalTopics = 0;
    var visitedTopics = 0;
    for(var i = 0; i < _this.trackingDataObj.length; i++) {
        for(var j = 0; j < _this.trackingDataObj[i].module.length; j++){
            totalTopics++;
            if(_this.trackingDataObj[i].module[j].topic.progress != ""){
                visitedTopics += ( parseFloat(_this.trackingDataObj[i].module[j].topic.progress) / 100 )
            }
        }
    }

   var progress = Math.floor(((visitedTopics / totalTopics) * 100)) + "%";
  
  _this.scormReference.storeProgress(progress);
    console.log("progress - "+progress);
}

_this.setSessionTime = function() {
    _this.scormReference.setSessionTime();
}
