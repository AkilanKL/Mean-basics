<?php 

$data =  $_GET["updatedData"];


$myfile = fopen("../data/content.json", "w") or die("Unable to open file!");

fwrite($myfile, $data);

fclose($myfile);

echo "updated";


?>