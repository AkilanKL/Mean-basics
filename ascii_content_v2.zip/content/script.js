var jsonDataFromFile = [];
var templateWrapper = document.getElementById("template-wrapper");
var buttonContainer = document.getElementById("save-download-data");
var coursePageContainer = document.getElementById("coursePageContainer");
var updatedStatusText = document.getElementById("status");

var saveBtn = document.getElementById("myBtn");
var currentCourse;

var getDataJSON = function (url, callback) {
  var xhr = new XMLHttpRequest();
  xhr.open("GET", url, true);
  xhr.responseType = "json";
  xhr.onload = function () {
    var status = xhr.status;
    if (status === 200) {
      callback(xhr.response);
    }
  };
  xhr.send();
};

var updateJsonData = function (url, jsonDataFromFile, callback) {
  var xhr = new XMLHttpRequest();
  xhr.open("GET", url+"?updatedData="+jsonDataFromFile, true);
  xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

  xhr.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      callback(xhr.responseText);
    }
  };
  xhr.send();
  
}
getDataJSON("../data/content.json", DataJsonSuccessHandler);
function DataJsonSuccessHandler(data) {
  jsonDataFromFile = data;
  if (jsonDataFromFile) {
    createDynamicTable(data);
  }
}
// function showMsgOnNoData() {
//     console.log("Show Error");
//     var table = document.createElement("table");
//     table.setAttribute("id", "bc");
//     table.setAttribute('border', "1");
//     table.innerHTML=`
//     <tr>
//         <th>Template Name</th>
//         <th>Heading</th>
//         <th>Question</th>
//         <th>Options</th>
//         <th>Correct Answer</th>
// `;
// document.getElementById("no-table").appendChild=table
// }


function createDynamicTable(data) {

  var coursePages = ""
  for(x in data) {
    coursePages = document.createElement("option");
    coursePages.value = x;
    coursePages.innerHTML = x;
    coursePageContainer.appendChild(coursePages)
  }

  if(data[coursePageContainer.value] != undefined) {
    templateWrapper.innerHTML = "";
    currentCourse = coursePageContainer.value;
    loadCourseDatas(data[currentCourse].knowledgeCheck)
  }

  // var loopData = data;
  // var table = document.createElement("table");
  // table.setAttribute("id", "mc");
  // table.setAttribute("border", "1");
  // table.innerHTML = `
  //       <tr>
  //           <th>Template Name</th>
  //           <th>Heading</th>
  //           <th>Question</th>
  //           <th>Options</th>
  //           <th>Correct Answer</th>
  //   `;
  // for (var i = 0; i < loopData.length; i++) {
  //   var tr = document.createElement("tr");
  //   var td1 = document.createElement("td");
  //   var td2 = document.createElement("td");
  //   var td3 = document.createElement("td");
  //   var td4 = document.createElement("td");
  //   var td5 = document.createElement("td");

  //   td1.innerHTML = loopData[i].templateName;
  //   td2.innerHTML = loopData[i].heading;
  //   td3.innerHTML = loopData[i].question;
  //   td4.innerHTML = loopData[i].options;
  //   td5.innerHTML = loopData[i].correctAnswer;
  //   tr.appendChild(td1);
  //   tr.appendChild(td2);
  //   tr.appendChild(td3);
  //   tr.appendChild(td4);
  //   tr.appendChild(td5);
  //   table.appendChild(tr);
  // }
  // document.getElementById("table").appendChild(table);
}

function courseChangeHandler(e) {
  templateWrapper.innerHTML = "";
  currentCourse = this.value;
  loadCourseDatas(jsonDataFromFile[currentCourse].knowledgeCheck)
}

coursePageContainer.addEventListener("change", courseChangeHandler);


document.addEventListener("click", function (e) {
  if(e.target.className == "remove-template"){
    removeTemplate(e)
  }
})

saveBtn.addEventListener("click", saveDatas);

function loadCourseDatas(courseData) {
  if(courseData.length > 0) {
    for(var i = 0; i < courseData.length; i++){
      switch(courseData[i].templateName) {
        case "multipleChoiseTemplate": 
           loadMultipleChoice(courseData[i], i);
           break;
      }
    }
  }
}

function loadMultipleChoice(multipleChoiseData, position) {
  var templateContainer = document.createElement("div");
  templateContainer.classList.add("multi-choise-template");
  templateContainer.classList.add("template-"+ position);

  /*---  Heading Element ---*/
  var heading = document.createElement("div");
  heading.classList.add("heading");
  heading.innerHTML = "Multiple Choise Templete";

   /*---  Remove Template button Element ---*/
   var removeButton = document.createElement("span");
   removeButton.classList.add("remove-template");
   removeButton.setAttribute("data-position", position)
   removeButton.innerHTML = "x";
   heading.appendChild(removeButton);

  /*---  question Element ---*/ 
  var questionContainer = document.createElement("div");
  questionContainer.classList.add("multi-choise-qus-container");
  var questionTxt = document.createElement("div");
  questionTxt.classList.add("text-labels");
  questionTxt.innerHTML = "Question:";

  questionContainer.appendChild(questionTxt);
  var templateQuestion = document.createElement("input");
  templateQuestion.classList.add("multi-choise-qus");
  templateQuestion.setAttribute("value", multipleChoiseData.question);
  questionContainer.appendChild(templateQuestion);

   /*---  Option Element ---*/ 
   var optionContainer = document.createElement("div");
   optionContainer.classList.add("multi-choise-opt-container");

   var optionTxt = document.createElement("div");
   optionTxt.classList.add("text-labels")
   optionTxt.innerHTML = "Options:";
   optionContainer.appendChild(optionTxt);

   var multiOptContainer = document.createElement("div");
   multiOptContainer.classList.add("multi-choise-options");

   for( var i = 0; i < multipleChoiseData.options.length; i++ ){
     var option = document.createElement("input");
     option.classList.add("multi-choise-opt");
     option.setAttribute("value", multipleChoiseData.options[i]);
     multiOptContainer.appendChild(option);
   }
   optionContainer.appendChild(multiOptContainer);

  /*---  Correct answer Element ---*/ 
  var ansContainer = document.createElement("div");
  ansContainer.classList.add("multi-ans-container");
  var ansTxt = document.createElement("div");
  ansTxt.classList.add("text-labels");
  ansTxt.innerHTML = "Correct Answer:";
  ansContainer.appendChild(ansTxt);
  var answer = document.createElement("input");
  answer.classList.add("multi-choise-ans");
  answer.setAttribute("value", multipleChoiseData.correctAnswer);
  ansContainer.appendChild(answer);



  templateContainer.appendChild(heading);
  templateContainer.appendChild(questionContainer);
  templateContainer.appendChild(optionContainer);
  templateContainer.appendChild(ansContainer);


  templateWrapper.appendChild(templateContainer);
}

function saveDatas () {
  var allTemplates = document.querySelectorAll("#template-wrapper > div");
  var knowledgeCheckArray = jsonDataFromFile[currentCourse].knowledgeCheck;

  for(var i= 0; i < knowledgeCheckArray.length; i++) {

    switch(knowledgeCheckArray[i].templateName) {
      case "multipleChoiseTemplate":
        var question = allTemplates[i].querySelector(".multi-choise-qus-container .multi-choise-qus").value;
        var options = allTemplates[i].querySelectorAll(".multi-choise-opt-container .multi-choise-opt");
        var answer = allTemplates[i].querySelector(".multi-ans-container .multi-choise-ans").value;

        jsonDataFromFile[currentCourse].knowledgeCheck[i].question = question;
        jsonDataFromFile[currentCourse].knowledgeCheck[i].options = [];

        for(var j = 0; j < options.length; j++) {
          jsonDataFromFile[currentCourse].knowledgeCheck[i].options.push(options[j].value);
        }

        jsonDataFromFile[currentCourse].knowledgeCheck[i].correctAnswer = answer;
        break;
    }
  }

  updateJsonData("updateJsonData.php", JSON.stringify(jsonDataFromFile), updateJsonHandler);

}

function updateJsonHandler(resopnse) {
  if(resopnse == "updated") {
    updatedStatusText.style.display = "block";
    setTimeout(function() {
      updatedStatusText.style.display = "none";
    }, 2000)
  }
}

document.getElementById("download").addEventListener("click", function () {
  var dataStr =
    "data:text/json;charset=utf-8," +
    encodeURIComponent(JSON.stringify(jsonDataFromFile));

  var downloadAnchorNode = document.createElement("a");
  downloadAnchorNode.setAttribute("href", dataStr);
  downloadAnchorNode.setAttribute("download", "content" + ".json");
  document.body.appendChild(downloadAnchorNode);
   downloadAnchorNode.click();
   downloadAnchorNode.remove();
});

function removeTemplate(e) {
  var templatePosition = parseInt(e.target.dataset.position);
  var removeTemplate = document.querySelector(".template-"+templatePosition);
  templateWrapper.removeChild(removeTemplate);
  jsonDataFromFile[currentCourse].knowledgeCheck.splice(templatePosition, 1);

}

function clearForm() {
  // templateName.value = "";
  heading.value = "";
  question.value = "";
  option1.value = "";
  option2.value = "";
  option3.value = "";
  option4.value = "";
  correctAnswer.value = "";
}
