#!/bin/bash
find . -path "*html-output/*" -type f -delete;
find . -name '*.adoc' -exec cp {} html-output/ \;
find . -path "*html-output/*.adoc" -exec asciidoctor {} \;
find . -path "*html-output/*.adoc" -type f -delete;