MultipleChoiseController = function() {

    _this = this;
    var submitButton, resetButton, formContainer;
    var attemptCount = 0;
    var jsonData;
    var globalController; 
    _this.loadUI = function(data, controller) {
        jsonData = data;
        globalController = controller;
        formContainer = document.getElementsByClassName("form-group");
        heading = document.getElementById("heading");
        submitButton = document.getElementById("submit-button");
        heading.innerHTML = jsonData.question;
        var optionsTexts = "";
        for(var i = 0; i < jsonData.options.length; i++) {
            optionsTexts += '<div class="label"><input type="radio" id="option-'+ i+'" value="'+jsonData.options[i]+'" name="multiple-choise"><label for="option-'+ i+'">'+jsonData.options[i]+'</label></div>';
        }
        formContainer[0].innerHTML = optionsTexts; 
        submitButton.addEventListener("click", _this.submitButtonHandler);

    }

    _this.submitButtonHandler = function() {
        var selectedObject = document.querySelector('input[name="multiple-choise"]:checked');
        if(selectedObject != null || selectedObject != undefined) {
            attemptCount++;
            var selectedValue = document.querySelector('input[name="multiple-choise"]:checked').value;
            if(selectedValue == jsonData.correctAnswer) {
               globalController.courseTrackingObj[globalController.currentIndex-1].isVisited = "true";
               globalController.courseTrackingObj[globalController.currentIndex-1].score = 1;
               globalController.courseTrackingObj[globalController.currentIndex-1].attemptCount = attemptCount;
               globalController.storeTrackingData(globalController.courseTrackingObj);
                alert("CORRECT ANSWER");      
            }else{
                globalController.courseTrackingObj[globalController.currentIndex-1].isVisited = "true";
                globalController.courseTrackingObj[globalController.currentIndex-1].score = 0;
                globalController.courseTrackingObj[globalController.currentIndex-1].attemptCount = attemptCount;
                globalController.storeTrackingData(globalController.courseTrackingObj);
                 alert("WRONG ANSWER");      
            }
        }
   
    }

    _this.init = function(data, controller) {
        _this.loadUI(data, controller);
    }

}


