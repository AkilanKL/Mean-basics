
var currentURL = window.location.pathname;
var htmlLocation = currentURL.indexOf(".html");
var topicLocation = htmlLocation - 1;
var topicConvention = "";

while(currentURL.substr(topicLocation, 1) !== "/") {
  topicConvention += currentURL.substr(topicLocation, 1);
  topicLocation--;
}

var moduleIndex = parseInt(topicConvention.split("-")[1]);
var topicIndex = parseInt(topicConvention.split("-")[0]);
var moduleTopicName = topicConvention.split("").reverse().join("");


var getDataJSON = function(url, callback) {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url, true);
    xhr.responseType = 'json';
    xhr.onload = function() {
      var status = xhr.status;
      if (status === 200) {
        callback(xhr.response);
      } 
    };
    xhr.send();
};

getDataJSON("data/content.json", DataJsonSuccessHandler);

function DataJsonSuccessHandler(data) {
    ApplicationController(data, moduleTopicName);
}
