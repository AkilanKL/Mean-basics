ApplicationController = function(jsonData, moduleTopicName) {

    var controller = this;

    controller.moduleTopicName = moduleTopicName;
    controller.jsonData = jsonData;

    controller.templateIndex, controller.currentTemplate;

    controller.isVideoCompleted = false;
    controller.isScrollCompleted = false;
    controller.isKnowledgeCheckCompleted = false;

    var videoFiles = document.querySelectorAll("video");

    var storedCourseTrackingObj = localStorage.getItem("courseTrackingObj"); 

    if(storedCourseTrackingObj == null || storedCourseTrackingObj == ""){
        controller.courseTrackingObj = {};

        for(x in jsonData){
            var tempObj = {}
                tempObj.isCompleted = false;
                tempObj.progress = "";
                tempObj.templateIndex = 1;
                tempObj.knowledgeCheck = [];

            var knowledgeCheckQuestions = jsonData[x].knowledgeCheck;
            for(var i = 0; i < knowledgeCheckQuestions.length; i++){
                tempObj.knowledgeCheck.push({score: 0, attemptCount: 0});
            }

            controller.courseTrackingObj[x] = tempObj;
        }

        localStorage.setItem("courseTrackingObj", JSON.stringify(controller.courseTrackingObj));
    }else{
        controller.courseTrackingObj = JSON.parse(storedCourseTrackingObj);
    }

    this.getHtmlTemplate = function(url, callback) {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', url, true);
        xhr.onload = function() {
          var status = xhr.status;
          if (status === 200) {
            callback(xhr.response);
          } 
        };
        xhr.send();
    }

    this.loadTemplate = function (moduleTopicName, templateIndex) {
        
        if(jsonData[moduleTopicName].knowledgeCheck.length > 1) {
            previousPageButton.style.pointerEvents = "none";
            nextPageButton.style.pointerEvents = "none";
        }

         controller.currentTemplate =  jsonData[moduleTopicName].knowledgeCheck[templateIndex - 1].templateName;
         var htmlTemplateURL = "templates/html/" + controller.currentTemplate + ".html";
         controller.getHtmlTemplate(htmlTemplateURL, controller.htmlTemplateSuccessHandler);

    }

    this.htmlTemplateSuccessHandler = function (html) {
        $("#parent-container").html("").html(html).promise().done(function () {
            if(jsonData[moduleTopicName].knowledgeCheck.length > 1) {

                if(templateIndex >=  jsonData[moduleTopicName].knowledgeCheck.length) {
                    nextPageButton.style.opacity = "0.3";
                    nextPageButton.style.pointerEvents = "none";
                }else{
                    nextPageButton.style.opacity = "1";
                    nextPageButton.style.pointerEvents = "auto";
                }
        
                if(templateIndex <=  1) {
                    previousPageButton.style.opacity = "0.3";
                    previousPageButton.style.pointerEvents = "none";
                }else{
                    previousPageButton.style.opacity = "1";
                    previousPageButton.style.pointerEvents = "auto";
                }
            }

            switch(controller.currentTemplate) {
                case "multipleChoiseTemplate":
                            var templateController = new MultipleChoiseController();

                             templateController.init(controller.jsonData[controller.moduleTopicName].knowledgeCheck[controller.templateIndex - 1], controller);
            }
        })
    }

    this.updateStatus = function (status) {
        if(status == "novideo" || status == "videocompleted") {
            controller.isVideoCompleted = true;
        }
        if(status == "noscroll" || status == "scrollcompleted") {
            controller.isScrollCompleted = true;
        }
        if(status == "noknowledgecheck" || status == "knowledgecheckcompleted"){
            controller.isKnowledgeCheckCompleted = true;
        }

        console.log("tracking status", status)

        if(controller.isVideoCompleted &&
             controller.isScrollCompleted &&
              controller.isKnowledgeCheckCompleted) {
                  console.log("Store data on LMS")
                controller.courseTrackingObj[controller.moduleTopicName].isCompleted = true;
                controller.courseTrackingObj[controller.moduleTopicName].progress = "100%";
            controller.storeTrackingData(controller.courseTrackingObj)
        }
    }

    this.nextPageHandler = function () {
        controller.templateIndex++;
        controller.loadTemplate(controller.moduleTopicName, controller.templateIndex);
    }

    this.previuosPageHandler = function () {
        controller.templateIndex--;
        controller.loadTemplate(controller.moduleTopicName, controller.templateIndex);
    }

    /*-------- store data on lms  --------*/

    this.storeTrackingData = function (trackingDta) {
        localStorage.setItem("courseTrackingObj", JSON.stringify(trackingDta));
    }

    /*-------- video completion tracking  --------*/

    this.videoEndHandler = function (e) {
        if(!controller.courseTrackingObj[controller.moduleTopicName].isCompleted){

            this.setAttribute("data-visited", true);
            var videoFiles = document.querySelectorAll("video");
            var visetedVideosCount = 0;

            for(var i = 0; i < videoFiles.length; i++) {
                if(videoFiles[i].dataset.visited == "true") {
                    visetedVideosCount++;
                }
            }

            if(visetedVideosCount == videoFiles.length) {
                controller.updateStatus("videocompleted");
            }

        }
    
    }

    if(!controller.courseTrackingObj[controller.moduleTopicName].isCompleted){
        if(videoFiles.length) {

            for(var i = 0; i < videoFiles.length; i++) {
                videoFiles[i].addEventListener('ended', controller.videoEndHandler);
            }
    
        }else{
            controller.updateStatus("novideo")
        }
    }


    /*-------- scroll completion tracking  --------*/

    function isScrollPresent() {
        return (document.body.offsetHeight > window.innerHeight) ? true : false;
      }
      
    function isScrollBarReachedBottom() {
       return (window.innerHeight + window.pageYOffset >= document.body.offsetHeight) ? true : false;
    }
      
    function scrollBarTracking() {
       if (!controller.isScrollCompleted) {
         if(isScrollBarReachedBottom()){
           updateStatus("scrollcompleted");
         }
       }
    }
      
    function setScrollBarTracking() {
       if (!controller.isScrollCompleted) {
         if(isScrollPresent()){
           window.removeEventListener("scroll", scrollBarTracking);
           window.addEventListener("scroll", scrollBarTracking);
         }else{
           controller.updateStatus("noscroll");
         }
       }
    }

    if(!controller.courseTrackingObj[controller.moduleTopicName].isCompleted){
        setScrollBarTracking();
        window.onresize = function(){ setScrollBarTracking() };
    }
      

    /*-------- knowledge check tracking and template loading--------*/

    if(jsonData[moduleTopicName].knowledgeCheck.length > 0) {

        if(jsonData[moduleTopicName].knowledgeCheck.length > 1) {
            var nextPageButton = document.getElementById("nextpage-button");
            var previousPageButton = document.getElementById("previouspage-button");
            nextPageButton.addEventListener("click", controller.nextPageHandler);
            previousPageButton.addEventListener("click", controller.previuosPageHandler);
        }else{
            var footerControl = document.getElementById("footer-controls");
            footerControl.style.display = "none";
        }
        controller.templateIndex =  controller.courseTrackingObj[controller.moduleTopicName].templateIndex
        controller.loadTemplate(controller.moduleTopicName, controller.templateIndex);

    }else{
        var footerControl = document.getElementById("footer-controls");
        footerControl.style.display = "none";  
        controller.updateStatus("noknowledgecheck");
    }
     





}