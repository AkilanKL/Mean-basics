var jsonDataFromFile = [];
var getDataJSON = function (url, callback) {
  var xhr = new XMLHttpRequest();
  xhr.open("GET", url, true);
  xhr.responseType = "json";
  xhr.onload = function () {
    var status = xhr.status;
    if (status === 200) {
      callback(xhr.response);
    }
  };
  xhr.send();
};
getDataJSON("content.json", DataJsonSuccessHandler);
function DataJsonSuccessHandler(data) {
  jsonDataFromFile = data;
  if (jsonDataFromFile) {
    createDynamicTable(data);
  }
}
// function showMsgOnNoData() {
//     console.log("Show Error");
//     var table = document.createElement("table");
//     table.setAttribute("id", "bc");
//     table.setAttribute('border', "1");
//     table.innerHTML=`
//     <tr>
//         <th>Template Name</th>
//         <th>Heading</th>
//         <th>Question</th>
//         <th>Options</th>
//         <th>Correct Answer</th>
// `;
// document.getElementById("no-table").appendChild=table
// }
function createDynamicTable(data) {
  console.log(data);
  var loopData = data;
  var table = document.createElement("table");
  table.setAttribute("id", "mc");
  table.setAttribute("border", "1");
  table.innerHTML = `
        <tr>
            <th>Template Name</th>
            <th>Heading</th>
            <th>Question</th>
            <th>Options</th>
            <th>Correct Answer</th>
    `;
  for (var i = 0; i < loopData.length; i++) {
    var tr = document.createElement("tr");
    var td1 = document.createElement("td");
    var td2 = document.createElement("td");
    var td3 = document.createElement("td");
    var td4 = document.createElement("td");
    var td5 = document.createElement("td");
    console.log(i);
    console.log(loopData[i]);
    td1.innerHTML = loopData[i].templateName;
    td2.innerHTML = loopData[i].heading;
    td3.innerHTML = loopData[i].question;
    td4.innerHTML = loopData[i].options;
    td5.innerHTML = loopData[i].correctAnswer;
    tr.appendChild(td1);
    tr.appendChild(td2);
    tr.appendChild(td3);
    tr.appendChild(td4);
    tr.appendChild(td5);
    table.appendChild(tr);
  }
  document.getElementById("table").appendChild(table);
}
document.getElementById("myBtn").addEventListener("click", function () {
  var templateName = document.getElementById("templateName").value;
  var heading = document.getElementById("heading").value;
  var question = document.getElementById("question").value;
  var option1 = document.getElementById("option1").value;
  var option2 = document.getElementById("option2").value;
  var option3 = document.getElementById("option3").value;
  var option4 = document.getElementById("option4").value;
  var correctAnswer = document.getElementById("correctAnswer").value;
  var options = [];
  options.push(option1, option2, option3, option4);
  console.log(options);
  var jsonData = {
    templateName: templateName,
    heading: heading,
    question: question,
    options: options,
    correctAnswer: correctAnswer,
  };
  console.log(jsonData);
  jsonDataFromFile.push(jsonData);
  console.log(jsonDataFromFile);
  var existtable = document.getElementById("mc");
  if (existtable) {
    existtable.remove();
  }
  createDynamicTable(jsonDataFromFile);
  clearForm();
});
document.getElementById("download").addEventListener("click", function () {
  var dataStr =
    "data:text/json;charset=utf-8," +
    encodeURIComponent(JSON.stringify(jsonDataFromFile));
  var downloadAnchorNode = document.createElement("a");
  downloadAnchorNode.setAttribute("href", dataStr);
  downloadAnchorNode.setAttribute("download", "content" + ".json");
  document.body.appendChild(downloadAnchorNode);
  downloadAnchorNode.click();
  downloadAnchorNode.remove();
});

function clearForm() {
  // templateName.value = "";
  heading.value = "";
  question.value = "";
  option1.value = "";
  option2.value = "";
  option3.value = "";
  option4.value = "";
  correctAnswer.value = "";
}
