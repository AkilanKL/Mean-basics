MultipleChoiseController = function() {

    _this = this;
    var submitButton, resetButton, formContainer;
    var attemptCount = 0;
    var jsonData;
    var globalController;
    var attemptCount = 0;
    this.loadUI = function(data, controller) {
        jsonData = data;
        globalController = controller;
        formContainer = document.getElementsByClassName("form-group");
        var questionContainer = document.getElementById("question");
        submitButton = document.getElementById("submit-button");
        questionContainer.innerHTML = jsonData.question;
        var optionsTexts = "";
        for(var i = 0; i < jsonData.options.length; i++) {
            optionsTexts += '<div class="label"><input type="radio" id="option-'+ i+'" value="'+jsonData.options[i]+'" name="multiple-choise"><label for="option-'+ i+'">'+jsonData.options[i]+'</label></div>';
        }
        formContainer[0].innerHTML = optionsTexts; 
        submitButton.addEventListener("click", _this.submitButtonHandler);

        if(!globalController.courseTrackingObj[globalController.moduleTopicName].isCompleted){
            _this.getProgressAndCompleteStatus();
        }

    }

    this.submitButtonHandler = function() {
        var selectedObject = document.querySelector('input[name="multiple-choise"]:checked');
        if(selectedObject != null || selectedObject != undefined) {
            attemptCount++;
            var selectedValue = document.querySelector('input[name="multiple-choise"]:checked').value;
            if(selectedValue == jsonData.correctAnswer) {
    
                globalController.courseTrackingObj[globalController.moduleTopicName].knowledgeCheck
                [globalController.templateIndex - 1].score = 1;
                globalController.courseTrackingObj[globalController.moduleTopicName].knowledgeCheck
                [globalController.templateIndex - 1].attemptCount = attemptCount;
                globalController.courseTrackingObj[globalController.moduleTopicName].templateIndex = 
                globalController.templateIndex

                if(!globalController.courseTrackingObj[globalController.moduleTopicName].isCompleted){
                    _this.getProgressAndCompleteStatus();
                    globalController.storeTrackingData(globalController.courseTrackingObj);
                }
               
                alert("CORRECT ANSWER");      
            }else{

                globalController.courseTrackingObj[globalController.moduleTopicName].knowledgeCheck
                [globalController.templateIndex - 1].score = 0;
                globalController.courseTrackingObj[globalController.moduleTopicName].knowledgeCheck
                [globalController.templateIndex - 1].attemptCount = attemptCount;
                globalController.courseTrackingObj[globalController.moduleTopicName].templateIndex = 
                globalController.templateIndex

                if(!globalController.courseTrackingObj[globalController.moduleTopicName].isCompleted){
                    _this.getProgressAndCompleteStatus();
                    globalController.storeTrackingData(globalController.courseTrackingObj);
                }
               
                alert("WRONG ANSWER");      
            }
        }
   
    }

    this.getProgressAndCompleteStatus = function () {

        var templatesArray = globalController.courseTrackingObj[globalController.moduleTopicName].knowledgeCheck;
        var templatesArrayLength = templatesArray.length;
        var totalQuestions = 0;
        var attemptedQuestions = 0;

        for(var i = 0; i < templatesArrayLength; i++){
            totalQuestions += 1;
            if(templatesArray[i].attemptCount > 0){
                attemptedQuestions += 1;
            }
        }

        if(attemptedQuestions == totalQuestions) {
            globalController.updateStatus("knowledgecheckcompleted");
        }
        
    }

    this.init = function(data, controller) {
        _this.loadUI(data, controller);
    }

}


